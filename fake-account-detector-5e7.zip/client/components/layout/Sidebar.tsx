import { Link, useLocation } from "react-router-dom";
import {
  BarChart3,
  Eye,
  Settings,
  TrendingUp,
  AlertTriangle,
  Search,
} from "lucide-react";

const Sidebar = () => {
  const location = useLocation();

  const menuItems = [
    { icon: Eye, label: "Overview", path: "/" },
    { icon: Search, label: "Account Analysis", path: "/analyze" },
    { icon: AlertTriangle, label: "Suspicious Clusters", path: "/clusters" },
    { icon: TrendingUp, label: "Trending Content", path: "/trends" },
    { icon: BarChart3, label: "Reports", path: "/reports" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border min-h-screen p-6 flex flex-col">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-cyan-400 mb-2 flex items-center gap-2">
          <AlertTriangle size={24} className="text-neon-cyan" />
          CYBERS
        </h2>
        <p className="text-xs text-sidebar-foreground/70">Security Analytics</p>
      </div>

      <nav className="flex-1 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive
                  ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                  : "text-sidebar-foreground hover:bg-sidebar-accent"
              }`}
            >
              <Icon size={20} />
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="pt-4 border-t border-sidebar-border">
        <p className="text-xs text-sidebar-foreground/50 px-4">
          Team CYBERS | CTF@048
        </p>
      </div>
    </aside>
  );
};

export default Sidebar;
