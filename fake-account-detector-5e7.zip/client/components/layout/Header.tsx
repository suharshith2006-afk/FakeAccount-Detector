import { Link, useLocation } from "react-router-dom";
import { Shield } from "lucide-react";

const Header = () => {
  const location = useLocation();

  const navItems = [
    { label: "Dashboard", path: "/" },
    { label: "Analyze Account", path: "/analyze" },
    { label: "Trends", path: "/trends" },
    { label: "Reports", path: "/reports" },
  ];

  return (
    <header className="bg-gradient-to-r from-slate-950 to-blue-950/50 border-b border-cyan-500/20 sticky top-0 z-50">
      <div className="max-w-full px-8 py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
              <Shield className="text-cyan-400" size={28} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                Fake Account Detection Dashboard
              </h1>
              <p className="text-xs text-blue-300/70">Team CYBERS | CTF@048</p>
            </div>
          </div>
        </div>

        <nav className="flex gap-8">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`text-sm font-medium pb-2 transition-all duration-200 ${
                  isActive
                    ? "text-cyan-400 border-b-2 border-cyan-400"
                    : "text-slate-300 hover:text-cyan-400 border-b-2 border-transparent"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
};

export default Header;
