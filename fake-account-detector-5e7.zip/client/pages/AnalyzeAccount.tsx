import { useState } from "react";
import { Search, AlertTriangle, CheckCircle } from "lucide-react";
import AppLayout from "@/components/layout/AppLayout";

interface AccountData {
  id: string;
  username: string;
  accountAge: string;
  followers: number;
  posts: number;
  classification: "genuine" | "fake" | "suspicious";
  suspicionScore: number;
  behaviorScore: number;
  contentScore: number;
  networkScore: number;
  trendScore: number;
  reasons: string[];
}

const AnalyzeAccount = () => {
  const [searchId, setSearchId] = useState("");
  const [accountData, setAccountData] = useState<AccountData | null>(null);
  const [searched, setSearched] = useState(false);

  const mockAccounts: { [key: string]: AccountData } = {
    "@user_1234": {
      id: "@user_1234",
      username: "user_1234",
      accountAge: "2 years",
      followers: 5420,
      posts: 342,
      classification: "genuine",
      suspicionScore: 12,
      behaviorScore: 8,
      contentScore: 15,
      networkScore: 10,
      trendScore: 5,
      reasons: [
        "Consistent posting patterns",
        "Real follower growth",
        "Authentic engagement",
      ],
    },
    "@suspicious_bot": {
      id: "@suspicious_bot",
      username: "suspicious_bot",
      accountAge: "3 months",
      followers: 50000,
      posts: 12500,
      classification: "fake",
      suspicionScore: 92,
      behaviorScore: 95,
      contentScore: 88,
      networkScore: 99,
      trendScore: 85,
      reasons: [
        "Sudden follower spike",
        "Repetitive content patterns",
        "Coordinated activity detected",
        "Unusual engagement metrics",
        "Links to bot network",
      ],
    },
    "@normal_account": {
      id: "@normal_account",
      username: "normal_account",
      accountAge: "1 year",
      followers: 1200,
      posts: 284,
      classification: "genuine",
      suspicionScore: 15,
      behaviorScore: 12,
      contentScore: 18,
      networkScore: 14,
      trendScore: 10,
      reasons: [
        "Natural follower growth rate",
        "Diverse content topics",
        "Human-like interaction patterns",
      ],
    },
    "@trending_user": {
      id: "@trending_user",
      username: "trending_user",
      accountAge: "6 months",
      followers: 25000,
      posts: 450,
      classification: "suspicious",
      suspicionScore: 58,
      behaviorScore: 65,
      contentScore: 55,
      networkScore: 62,
      trendScore: 48,
      reasons: [
        "Rapid growth detected",
        "Mixed genuine and suspicious patterns",
        "Some coordinated behavior found",
      ],
    },
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);

    if (searchId.toLowerCase() in mockAccounts) {
      setAccountData(
        mockAccounts[searchId.toLowerCase() as keyof typeof mockAccounts]
      );
    } else {
      setAccountData(null);
    }
  };

  const ScoreBar = ({
    label,
    score,
  }: {
    label: string;
    score: number;
  }) => {
    let color = "bg-green-500";
    if (score > 60) color = "bg-red-500";
    else if (score > 40) color = "bg-yellow-500";

    return (
      <div className="mb-4">
        <div className="flex justify-between mb-2">
          <label className="text-sm text-slate-300">{label}</label>
          <span className="text-sm font-semibold text-cyan-400">{score}%</span>
        </div>
        <div className="w-full bg-slate-700/50 rounded-full h-2 overflow-hidden border border-slate-600/50">
          <div
            className={`h-full ${color} transition-all duration-500`}
            style={{ width: `${score}%` }}
          />
        </div>
      </div>
    );
  };

  return (
    <AppLayout>
      <div className="p-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-cyan-400 mb-2">
            Analyze Account
          </h2>
          <p className="text-slate-400">
            Search for an account to view detailed security analysis
          </p>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="mb-8">
          <div className="relative max-w-md">
            <input
              type="text"
              placeholder="Enter account ID (e.g., @user_1234)"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              className="w-full px-4 py-3 bg-slate-900/50 border border-cyan-500/30 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 transition-all"
            />
            <button
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-lg transition-all border border-cyan-500/30"
            >
              <Search size={20} className="text-cyan-400" />
            </button>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            Try: @user_1234, @suspicious_bot, @normal_account, or @trending_user
          </p>
        </form>

        {searched && !accountData && (
          <div className="neon-border p-8 rounded-lg backdrop-blur-sm text-center">
            <p className="text-slate-400">
              Account not found. Please try another account ID.
            </p>
          </div>
        )}

        {accountData && (
          <div className="space-y-6">
            {/* Account Header */}
            <div className="neon-border p-8 rounded-lg backdrop-blur-sm">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-cyan-400 mb-2">
                    {accountData.username}
                  </h3>
                  <p className="text-slate-400">{accountData.id}</p>
                </div>
                <div
                  className={`px-4 py-2 rounded-lg font-semibold flex items-center gap-2 ${
                    accountData.classification === "genuine"
                      ? "bg-green-500/20 text-green-400 border border-green-500/30"
                      : accountData.classification === "suspicious"
                        ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
                        : "bg-red-500/20 text-red-400 border border-red-500/30"
                  }`}
                >
                  {accountData.classification === "genuine" ? (
                    <CheckCircle size={16} />
                  ) : (
                    <AlertTriangle size={16} />
                  )}
                  {accountData.classification.charAt(0).toUpperCase() +
                    accountData.classification.slice(1)}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-700/50">
                <div>
                  <p className="text-xs text-slate-400 mb-1">Account Age</p>
                  <p className="text-lg font-semibold text-slate-200">
                    {accountData.accountAge}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Followers</p>
                  <p className="text-lg font-semibold text-slate-200">
                    {accountData.followers.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Posts</p>
                  <p className="text-lg font-semibold text-slate-200">
                    {accountData.posts.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>

            {/* Suspicion Score */}
            <div className="neon-border p-8 rounded-lg backdrop-blur-sm">
              <h3 className="text-lg font-semibold text-cyan-400 mb-6">
                Overall Suspicion Score
              </h3>
              <div className="flex items-center justify-between mb-4">
                <div className="text-6xl font-bold text-cyan-400">
                  {accountData.suspicionScore}
                </div>
                <div className="text-right">
                  <p className="text-sm text-slate-400 mb-2">Risk Level</p>
                  <div
                    className={`px-4 py-2 rounded-lg font-semibold ${
                      accountData.suspicionScore > 70
                        ? "bg-red-500/20 text-red-400"
                        : accountData.suspicionScore > 40
                          ? "bg-yellow-500/20 text-yellow-400"
                          : "bg-green-500/20 text-green-400"
                    }`}
                  >
                    {accountData.suspicionScore > 70
                      ? "High Risk"
                      : accountData.suspicionScore > 40
                        ? "Medium Risk"
                        : "Low Risk"}
                  </div>
                </div>
              </div>
              <div className="w-full bg-slate-700/50 rounded-full h-3 overflow-hidden border border-slate-600/50">
                <div
                  className={`h-full transition-all duration-500 ${
                    accountData.suspicionScore > 70
                      ? "bg-red-500"
                      : accountData.suspicionScore > 40
                        ? "bg-yellow-500"
                        : "bg-green-500"
                  }`}
                  style={{ width: `${accountData.suspicionScore}%` }}
                />
              </div>
            </div>

            {/* Feature Scores */}
            <div className="neon-border p-8 rounded-lg backdrop-blur-sm">
              <h3 className="text-lg font-semibold text-cyan-400 mb-6">
                Feature Breakdown
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <ScoreBar label="Behavior Score" score={accountData.behaviorScore} />
                  <ScoreBar label="Content Score" score={accountData.contentScore} />
                </div>
                <div>
                  <ScoreBar label="Network Score" score={accountData.networkScore} />
                  <ScoreBar label="Trend Score" score={accountData.trendScore} />
                </div>
              </div>
            </div>

            {/* Reasons for Detection */}
            <div className="neon-border p-8 rounded-lg backdrop-blur-sm">
              <h3 className="text-lg font-semibold text-cyan-400 mb-4">
                Analysis Summary
              </h3>
              <ul className="space-y-2">
                {accountData.reasons.map((reason, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-3 text-slate-300"
                  >
                    <span className="text-cyan-400 font-bold mt-0.5">•</span>
                    <span>{reason}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {!searched && (
          <div className="neon-border p-12 rounded-lg backdrop-blur-sm text-center">
            <Search size={48} className="text-cyan-400/50 mx-auto mb-4" />
            <p className="text-slate-400">
              Enter an account ID above to start analyzing
            </p>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default AnalyzeAccount;
