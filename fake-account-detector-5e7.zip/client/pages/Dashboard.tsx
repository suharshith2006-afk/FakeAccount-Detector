import { useState, useEffect, Suspense, lazy } from "react";
import { AlertTriangle, BarChart3, TrendingUp, Users } from "lucide-react";
import AppLayout from "@/components/layout/AppLayout";

const ChartComponents = lazy(() => import("@/components/Charts"));

const Dashboard = () => {
  const [accountStats, setAccountStats] = useState({
    totalAnalyzed: 15240,
    fakeDetected: 3421,
    suspiciousAccounts: 892,
    activeTrends: 47,
  });

  const [fakeVsGenuineData] = useState([
    { name: "Genuine", value: 11819, fill: "#00ff00" },
    { name: "Fake", value: 3421, fill: "#ff0000" },
  ]);

  const [activityData] = useState([
    { date: "Jan 1", activity: 420, detections: 45 },
    { date: "Jan 8", activity: 560, detections: 78 },
    { date: "Jan 15", activity: 720, detections: 125 },
    { date: "Jan 22", activity: 890, detections: 156 },
    { date: "Jan 29", activity: 1050, detections: 213 },
    { date: "Feb 5", activity: 1320, detections: 287 },
    { date: "Feb 12", activity: 1540, detections: 389 },
  ]);

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setAccountStats((prev) => ({
        ...prev,
        totalAnalyzed: prev.totalAnalyzed + Math.floor(Math.random() * 10),
        fakeDetected: prev.fakeDetected + Math.floor(Math.random() * 3),
        suspiciousAccounts: prev.suspiciousAccounts + Math.floor(Math.random() * 2),
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const StatCard = ({
    icon: Icon,
    label,
    value,
    trend,
    color,
  }: {
    icon: React.ComponentType<{ size: number; className?: string }>;
    label: string;
    value: number;
    trend?: string;
    color: string;
  }) => (
    <div className="neon-border p-6 rounded-lg backdrop-blur-sm hover:shadow-lg transition-all duration-300 hover:border-cyan-500/50 group">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-slate-400 mb-2">{label}</p>
          <p className="text-3xl font-bold text-cyan-400">
            {value.toLocaleString()}
          </p>
          {trend && (
            <p className="text-xs text-green-400 mt-2 flex items-center gap-1">
              <TrendingUp size={12} /> {trend}
            </p>
          )}
        </div>
        <div className={`p-3 rounded-lg bg-${color}-500/10 border border-${color}-500/30 group-hover:border-${color}-500/60 transition-all`}>
          <Icon size={24} className={`text-${color}-400`} />
        </div>
      </div>
    </div>
  );

  return (
    <AppLayout>
      <div className="p-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-cyan-400 mb-2">Overview</h2>
          <p className="text-slate-400">
            Real-time detection analytics and account security metrics
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            icon={Users}
            label="Total Accounts Analyzed"
            value={accountStats.totalAnalyzed}
            color="cyan"
          />
          <StatCard
            icon={AlertTriangle}
            label="Fake Accounts Detected"
            value={accountStats.fakeDetected}
            trend="+12.5%"
            color="red"
          />
          <StatCard
            icon={AlertTriangle}
            label="Suspicious Accounts"
            value={accountStats.suspiciousAccounts}
            trend="+8.2%"
            color="yellow"
          />
          <StatCard
            icon={TrendingUp}
            label="Active Trends Detected"
            value={accountStats.activeTrends}
            color="purple"
          />
        </div>

        {/* Charts */}
        <Suspense
          fallback={
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="neon-border p-6 rounded-lg backdrop-blur-sm h-80 flex items-center justify-center">
                <p className="text-slate-400">Loading chart...</p>
              </div>
              <div className="neon-border p-6 rounded-lg backdrop-blur-sm h-80 flex items-center justify-center">
                <p className="text-slate-400">Loading chart...</p>
              </div>
            </div>
          }
        >
          <ChartComponents
            fakeVsGenuineData={fakeVsGenuineData}
            activityData={activityData}
          />
        </Suspense>

        {/* Recent Activity */}
        <div className="neon-border p-6 rounded-lg backdrop-blur-sm mt-6">
          <h3 className="text-lg font-semibold text-cyan-400 mb-4">
            Recent Detections
          </h3>
          <div className="space-y-2 text-sm text-slate-300">
            <div className="flex items-center justify-between py-2 border-b border-slate-800/50">
              <span>@suspicious_user_2847</span>
              <span className="text-red-400 font-semibold">Fake Account</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-slate-800/50">
              <span>@botnet_cluster_42</span>
              <span className="text-red-400 font-semibold">Coordinated Network</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-slate-800/50">
              <span>@trending_spam_hashtag</span>
              <span className="text-yellow-400 font-semibold">Suspicious Trend</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span>@legitimate_user_9501</span>
              <span className="text-green-400 font-semibold">Genuine</span>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
