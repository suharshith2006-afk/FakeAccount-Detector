import Placeholder from "./Placeholder";
import { TrendingUp } from "lucide-react";

const Trends = () => {
  return (
    <Placeholder
      title="Trending Content"
      description="View top hashtags, repeated posts, and rapidly spreading content with timeline analysis."
      icon={TrendingUp}
    />
  );
};

export default Trends;
