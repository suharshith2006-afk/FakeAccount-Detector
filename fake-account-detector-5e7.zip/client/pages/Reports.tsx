import Placeholder from "./Placeholder";
import { BarChart3 } from "lucide-react";

const Reports = () => {
  return (
    <Placeholder
      title="Reports"
      description="View detailed reports of analyzed accounts with filters for Genuine, Fake, and Suspicious classifications."
      icon={BarChart3}
    />
  );
};

export default Reports;
